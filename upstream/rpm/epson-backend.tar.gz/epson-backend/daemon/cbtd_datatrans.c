/*
 * Copyright (C) Seiko Epson Corporation 2014.
 *
 * This file is part of the `ecbd' program.
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * As a special exception, AVASYS CORPORATION gives permission
 * to link the code of this program with the `cbt' library and
 * distribute linked combinations including the two.  You must obey
 * the GNU General Public License in all respects for all of the
 * code used other then `cbt'.
 */
#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cbtd.h"
#include "libcbt.h"
#include "cbtd_thread.h"

#define DATA_BUF_SIZE 0x1000	/* size of data which can read at a time */
#define INPUT_TIMEOUT 60	/* timeout of input */
#define	kFIFOBlockSize	DATA_BUF_SIZE
#define	kFIFOTotalSize	(1024*1024*5)
#define	kFIFO1stIncreaseSize	(64)
#define	kRingQueueAutoFlushTimeMilliSec		(500)

typedef enum {
	CanReadResult_OK	= 0,
	CanReadResult_Empty,
	CanReadResult_Busy
} rqCanReadResult;


typedef struct
{
	int				fd;
	P_CBTD_INFO		p_info;
	void*			ring;
	volatile bool	cancel;
	volatile bool	complete;
} FIFOContext;

static bool IsCancel_datatrans_work (FIFOContext* pfifo);
static void datatrans_work (P_CBTD_INFO, int);
static void datatrans_work_read (FIFOContext* fifo);
static int fifo_open (P_CBTD_INFO, char*);
static void datatrans_cleanup (void*);
static void lpd_stop (P_CBTD_INFO);
static void lpd_start (P_CBTD_INFO);

static void*			RingQueue_Initialize(int blocksize, int numBlocks);
static void				RingQueue_Terminate(void* instance);
static int				RingQueue_Write(void* instance, const char* src, int requestSize, bool* updated);
static bool				RingQueue_SetFlush(void* instance);
//static bool			RingQueue_IsEmpty(void* instance);
static rqCanReadResult	RingQueue_CanReadStart(void* instance);
static int				RingQueue_ReadStart(void* instance, char* *buf, int *size);
static void				RingQueue_ReadEnd(void* instance);
static void				RingQueue_Lock(void* instance);
static void				RingQueue_Unlock(void* instance);


static int _datatrans_lpr_flag;


/* Thread to send printing data */
void
datatrans_thread (P_CBTD_INFO p_info)
{
	int fifo_fd;
	char* fifo_path = p_info->infifo_path;
	CARGS cargs;
	int set_flags, reset_flags;

	_DEBUG_MESSAGE_VAL("datatrans thread ID : ", (int)pthread_self());
	_datatrans_lpr_flag = 0;

	cargs.p_info = p_info;
	cargs.p_max = &fifo_fd;
	pthread_cleanup_push (datatrans_cleanup, (void *)&cargs);

	for (;;)
	{
		fifo_fd = fifo_open (p_info, fifo_path);
		if (fifo_fd < 0)
		{
			perror (fifo_path);
			break;
		}

		/* Is daemon in the middle of process for end ? */
		if (is_sysflags (p_info, ST_SYS_DOWN)) {
			if (fifo_fd)
				close (fifo_fd);
			break;
		}

		p_info->datatrans_thread_status = THREAD_RUN;
		set_sysflags (p_info, ST_JOB_PRINTING);
      
		set_flags = 0;
		reset_flags = ST_PRT_CONNECT | ST_SYS_DOWN | ST_JOB_CANCEL;

		wait_sysflags (p_info, set_flags, reset_flags, 0, WAIT_SYS_AND);
      
		if (is_sysflags (p_info, ST_PRT_CONNECT))
		{
			/* send and receive of printing data */
			    open_port_channel (p_info, SID_DATA);
				datatrans_work (p_info, fifo_fd);
				close_port_channel (p_info, SID_DATA);
		}
		reset_sysflags (p_info, ST_JOB_PRINTING);
      
		if (fifo_fd)
			close (fifo_fd);

		if (is_sysflags (p_info, ST_SYS_DOWN))
			break;
	}
  
	pthread_cleanup_pop (1);
	return;
}

static bool IsCancel_datatrans_work (FIFOContext* pfifo)
{
	if( pfifo->cancel == false )
	{
		if (	 is_sysflags (pfifo->p_info, ST_JOB_CANCEL)
			||	!is_sysflags (pfifo->p_info, ST_PRT_CONNECT)
			||	 is_sysflags (pfifo->p_info, ST_SYS_DOWN)
		){
			pfifo->cancel = true;			// cancel
		}
	}
	return pfifo->cancel;
}

/* Send and receive of printing data */
static void
datatrans_work (P_CBTD_INFO p_info, int fd)
{
	FIFOContext	fifo;

	fifo.p_info		= p_info;
	fifo.cancel		= false;
	fifo.complete	= false;
	fifo.fd			= fd;
	fifo.ring		= RingQueue_Initialize(kFIFOBlockSize, kFIFOTotalSize/kFIFOBlockSize);

	if( fifo.ring ){
		HANDLE	thread = init_thread (CBTD_THREAD_STACK_SIZE, (void *)datatrans_work_read, (void *)&fifo);

		if( thread ){
			int	sleepTimeMilliSec	= 0;
			int	busyFlushTimer		= 0;

			while( IsCancel_datatrans_work(&fifo) == false ){
				rqCanReadResult	mode = RingQueue_CanReadStart(fifo.ring);

				if( mode == CanReadResult_OK ){
					int		read_size	= 0;
					char*	buffer		= NULL;
				
					RingQueue_ReadStart(fifo.ring, &buffer, &read_size);
					if( buffer  &&  read_size > 0 ){

						/* send printing data to a printer */
						int write_size = read_size;
						do{
							if( IsCancel_datatrans_work(&fifo) == true ){
								break;
							}

							enter_critical (p_info->ecbt_accsess_critical);

							int tmp_size = write_size;
							int err = write_to_prt(	p_info,
											SID_DATA,
											buffer + (read_size - write_size),
											&write_size);
							write_size = tmp_size - write_size;

							leave_critical (p_info->ecbt_accsess_critical);
							
							if (p_info->sleepTime > 0 && err == 0) {
								writeLogFile("datatrans_work:sleep\n");
								Sleep(p_info->sleepTime);
							} else if (err == 1) {
								Sleep(100);
							}

						}
						while (write_size > 0);
					}


					RingQueue_ReadEnd(fifo.ring);
					sleepTimeMilliSec	= 0;
					busyFlushTimer		= 0;
				}
				else{
					if( mode == CanReadResult_Empty ){
						if( fifo.complete == true ){
							break;
						}

						busyFlushTimer = 0;
					}
					else{	//	CanReadResult_Busy
						if( busyFlushTimer == 0 ){
							busyFlushTimer = 1;
						}
						else if( busyFlushTimer < kRingQueueAutoFlushTimeMilliSec ){
							busyFlushTimer += busyFlushTimer;
						}
					}

					if(		busyFlushTimer < kRingQueueAutoFlushTimeMilliSec
						||	RingQueue_SetFlush(fifo.ring) == false	// try busy flush.
					){
						if( sleepTimeMilliSec == 0 ){
							sleepTimeMilliSec = 1;
						}
						else{
							sleepTimeMilliSec += sleepTimeMilliSec;
							if( sleepTimeMilliSec >= 100 ){
								sleepTimeMilliSec = 100;
							}
						}
						usleep(sleepTimeMilliSec*1000);
					}
				}
			}

			delete_thread(thread);
		}
		RingQueue_Terminate(fifo.ring);
	}
}

static void datatrans_work_read (FIFOContext* pfifo)
{
	char *data_buf = calloc (DATA_BUF_SIZE, sizeof (char));

	if( data_buf ){
		while( IsCancel_datatrans_work(pfifo) == false )		/* in this moment, system can communicate with a printer */
		{
			int read_size	= 0;
			int	retry		= 0;

			do{
				read_size = read (pfifo->fd, data_buf, DATA_BUF_SIZE);	// receive printing data
				if( read_size <= 0 ){
					usleep(100*1000);
				}
				retry++;

			}while( IsCancel_datatrans_work(pfifo) == false  &&  retry < INPUT_TIMEOUT  &&  read_size <= 0 );

			if( IsCancel_datatrans_work(pfifo) == true ){
				break;											// cancel.
			}

			if (read_size <= 0){
				while( RingQueue_SetFlush(pfifo->ring) == false  &&  IsCancel_datatrans_work(pfifo) == false ){
					usleep(100*1000);
				}
				break;
			}
			else{
				bool	updated				= false;
				char*	pp					= data_buf;
				int		rest_size			= read_size;
				int		sleepTimeMilliSec	= 1;

				while( rest_size > 0  &&  IsCancel_datatrans_work(pfifo) == false ){
					int	act_size = RingQueue_Write(pfifo->ring, pp, rest_size, &updated);

					if( act_size > 0 ){
						pp				 += act_size;
						rest_size		 -= act_size;
						sleepTimeMilliSec = 1;
					}
					else{
						usleep(sleepTimeMilliSec * 1000);

						sleepTimeMilliSec += sleepTimeMilliSec;
						if( sleepTimeMilliSec > 100 ){
							sleepTimeMilliSec = 100;
						}
					}
				}
			}
		}
	}

	if( data_buf ){
		free(data_buf);
	}

	pfifo->complete = true;
}

/* open the named pipe */
static int
fifo_open (P_CBTD_INFO p_info, char* path)
{
	int fd;
	int old_mask;

	if (access (path, F_OK) == 0)
	{
		if (remove(path))
		{
			return -1;
		}
	}

	old_mask = umask(0);

	if (mkfifo (path, 0666))
	{
		umask(old_mask);
		return -1;
	}

	umask(old_mask);

	if (is_sysflags (p_info, ST_JOB_CANCEL | ST_JOB_CANCEL_NO_D4))
	{
		wait_sysflags (p_info, ST_JOB_CANCEL | ST_JOB_CANCEL_NO_D4, 0, 0, WAIT_SYS_AND);
	}
	/* wait till there is input */
	lpd_start (p_info);
	fd = open (path, O_RDONLY);

	if (fd < 0)
	{
		return -1;
	}
	return fd;
}


/*  end of thread */
static void
datatrans_cleanup (void* data)
{
	P_CARGS p_cargs = (P_CARGS)data;
	int fd = *(p_cargs->p_max);

	close (fd);
	if (!is_sysflags (p_cargs->p_info, ST_SYS_DOWN))
		set_sysflags (p_cargs->p_info, ST_SYS_DOWN);

	p_cargs->p_info->datatrans_thread_status = THREAD_DOWN;
	_DEBUG_MESSAGE("Data transfer thread ...down");
	return;
}


/* eliminate print job in process with lpd and turn a printer into
   temporary halt */
static void
lpd_stop (P_CBTD_INFO p_info)
{

	/* In case of printer that a D4 command is not supported, wait
	   till a printer reset it */
	if (is_sysflags (p_info, ST_JOB_CANCEL_NO_D4))
	{
		reset_sysflags (p_info, ST_JOB_PRINTING);
		wait_sysflags (p_info, ST_JOB_CANCEL, 0, 0, WAIT_SYS_AND);
	}

	if (!access ("/var/run/lpr_lock", F_OK))
	{
		char* com_buf;

		/* command + printer name + \0 */
		com_buf = malloc (10 + strlen (p_info->printer_name) + 1);

		/* printing stop */
		strcpy (com_buf, "lpc stop ");
		strcat (com_buf, p_info->printer_name);
		system (com_buf);

		/* delete Job */
		strcpy (com_buf, "lprm -P");
		strcat (com_buf, p_info->printer_name);
		system (com_buf);

		free (com_buf);
		/* lpr stops */
		_datatrans_lpr_flag = 1;
	}

	return;
}


/* restart lpd */
static void
lpd_start (P_CBTD_INFO p_info)
{
	if (_datatrans_lpr_flag)
	{
		char* com_buf;

		/* command + printer name + \0 */
		com_buf = malloc (10 + strlen (p_info->printer_name) + 1);

		/* printing start */
		strcpy (com_buf, "lpc start ");
		strcat (com_buf, p_info->printer_name);
		system (com_buf);

		free (com_buf);
		_datatrans_lpr_flag = 0;
	}

	return;
}


//----------------------
typedef struct _rqElement {
	char*					addr;
	int						pos;
	struct _rqElement		*next;
} rqElement, *rqElementPtr;

typedef struct
{
	pthread_mutex_t		m_mutex;
	char*				m_buffer;
	int					m_blocksize;
	int					m_increaseSize;
	rqElementPtr		m_wp;
	rqElementPtr		m_rp;
} RingQueueContext;


static void* RingQueue_Initialize(int blocksize, int numBlocks)
{
	RingQueueContext*	context = (RingQueueContext*)malloc(sizeof(RingQueueContext));
	if( context ){
		rqElementPtr	anElm,anElmTop;
		char*			addr;
		int				totalsize;

		pthread_mutex_init(&context->m_mutex, NULL);
		context->m_buffer		= NULL;
		context->m_increaseSize	= (blocksize > kFIFO1stIncreaseSize)
											 ? kFIFO1stIncreaseSize
											 : blocksize;
		if (	blocksize <= 1
			||	numBlocks <= 2
		) {
			free(context);
			return NULL;
		}

		context->m_blocksize	= blocksize;
		totalsize				= ( context->m_blocksize + sizeof(rqElement) ) * numBlocks;

		context->m_buffer = (char*)malloc(totalsize);
		if (context->m_buffer == NULL) {
			free(context);
			return NULL;
		}
		addr = (char*)context->m_buffer;

		anElmTop		= (rqElementPtr)(addr + blocksize * numBlocks);
		context->m_wp	= anElmTop;
		context->m_rp	= anElmTop;
		anElm			= anElmTop;
		int xx;
		for (xx = 0;  xx < numBlocks - 1;  xx++) {
			anElm->addr		= addr;
			anElm->pos		= 0;
			anElm->next		= (rqElementPtr)((char*)anElm + sizeof(rqElement));	// next queue
			addr  			+= blocksize;
			anElm			= anElm->next;
		}
		// last queue
		anElm->addr		= addr;	
		anElm->pos		= 0;
		anElm->next		= anElmTop;		// endless queue link. 
	}
	return context;
}

static void RingQueue_Terminate(void* instance)
{
	RingQueueContext*	context = (RingQueueContext*)instance;
	if( context ){
		if (context->m_buffer) {
			free(context->m_buffer);
			context->m_buffer = NULL;
		}
		pthread_mutex_destroy(&context->m_mutex);
		free(context);
	}
}

static int RingQueue_Write(void* instance, const char* src, int requestSize, bool* updated)
{
	int					rest	= requestSize;
	RingQueueContext*	context = (RingQueueContext*)instance;

	if( context  &&  context->m_buffer  &&  src  &&  requestSize > 0  &&  updated){
		RingQueue_Lock(context);

		// update best increase size.
		while(	context->m_increaseSize < context->m_blocksize
			&&  context->m_increaseSize * 2 <= requestSize + context->m_wp->pos
		){
			context->m_increaseSize += context->m_increaseSize;
		}

		int				space, blockSize;
		rqElementPtr	rp	= context->m_rp;

		*updated = false;

		while (rest > 0  &&  context->m_wp->next != rp) {
			blockSize = (context->m_blocksize <= context->m_increaseSize)
												?	context->m_blocksize
												:	context->m_increaseSize;
			space = blockSize - context->m_wp->pos;

			if (rest >= space) {
				if (space > 0)
					memmove(context->m_wp->addr + context->m_wp->pos, src, space);	// can not use memcpy().

				src					+= space;		// set new pointer
				context->m_wp->pos	+= space;		// increment write position
				rest				-= space;		// decrement writed size

				*updated			= true;
				context->m_wp		= context->m_wp->next;	// next wp !!!
				context->m_wp->pos	= 0;

				if (context->m_increaseSize < context->m_blocksize){
					context->m_increaseSize += context->m_increaseSize;
				}
			}
			else if (rest > 0) {
				memmove(context->m_wp->addr + context->m_wp->pos, src, rest);	// can not use memcpy().
				context->m_wp->pos 	+= rest;
				rest				 = 0;
			}
		}
		if (rest > 0) {		// (rest > 0) means that context->m_wp->next == rp, then can not flush.
			blockSize = (context->m_blocksize <= context->m_increaseSize)
												?	context->m_blocksize
												:	context->m_increaseSize;
			space = blockSize - context->m_wp->pos - 1;			// "-1".....Important

			if (space > 0) {
				if (rest >= space) {
					memmove(context->m_wp->addr + context->m_wp->pos, src, space);	// can not use memcpy().
					context->m_wp->pos	+= space;		// increment write position
					rest				-= space;		// decrement writed size
				}
				else {
					if (rest > 0)
						memmove(context->m_wp->addr + context->m_wp->pos, src, rest);	// can not use memcpy().
					context->m_wp->pos 	+= rest;
					rest				 = 0;
				}
			}
		}
		RingQueue_Unlock(context);
	}
	return(requestSize - rest);		// Actual writed size (byte).
}

static bool RingQueue_SetFlush(void* instance)
{
	bool	flushed = false;

	RingQueueContext*	context = (RingQueueContext*)instance;
	if( context ){
		RingQueue_Lock(context);

		rqElementPtr	rp = context->m_rp;

		if (context->m_buffer != NULL) {
			if (context->m_wp->next != rp  &&  context->m_wp->next->next != rp) {
				if (context->m_wp->pos > 0) {
					context->m_wp = context->m_wp->next;
				}
				flushed = true;
			}
		}
		RingQueue_Unlock(context);
	}
	return(flushed);
}

/*
static bool	RingQueue_IsEmpty(void* instance)
{
	RingQueueContext*	context = (RingQueueContext*)instance;
	if( context ){
		rqElementPtr	rp = context->m_rp;

		if (context->m_buffer != NULL) {
			if (rp != context->m_wp  ||  rp->pos != 0) {
				return(false);
			}
		}
	}
	return(true);
}
*/

static rqCanReadResult RingQueue_CanReadStart(void* instance)
{
	RingQueueContext*	context = (RingQueueContext*)instance;
	if( context ){
		if (context->m_buffer == NULL)		return(CanReadResult_Empty);
		if (context->m_rp != context->m_wp)	return(CanReadResult_OK);
		if (context->m_rp->pos == 0)		return(CanReadResult_Empty);
		return(CanReadResult_Busy);
	}
	return(CanReadResult_Empty);
}

static int RingQueue_ReadStart(void* instance, char* *buf, int *size)
{
	RingQueueContext*	context = (RingQueueContext*)instance;
	if( context ){
		if (context->m_buffer  &&  context->m_rp != context->m_wp) {
			*buf	= context->m_rp->addr;
			*size	= context->m_rp->pos;
			return(*size);
		}
	}
	return(0);
}

static void RingQueue_ReadEnd(void* instance)
{
	RingQueueContext*	context = (RingQueueContext*)instance;
	if( context ){
		if (context->m_buffer  &&  context->m_rp != context->m_wp) {
			context->m_rp->pos	= 0;					// reset size
			context->m_rp		= context->m_rp->next;	// next rp.
		}
	}
}

static void RingQueue_Lock(void* instance)
{
	RingQueueContext*	context = (RingQueueContext*)instance;
	if( context ){
		pthread_mutex_lock(&context->m_mutex);
	}
}

static void RingQueue_Unlock(void* instance)
{
	RingQueueContext*	context = (RingQueueContext*)instance;
	if( context ){
		pthread_mutex_unlock(&context->m_mutex);
	}
}

