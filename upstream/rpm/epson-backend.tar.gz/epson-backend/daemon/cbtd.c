/*
 * Copyright (C) Seiko Epson Corporation 2014.
 *
 * This file is part of the `ecbd' program.
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * As a special exception, AVASYS CORPORATION gives permission
 * to link the code of this program with the `cbt' library and
 * distribute linked combinations including the two.  You must obey
 * the GNU General Public License in all respects for all of the
 * code used other then `cbt'.
 */

/*
 * Restrictions
 *      Cannot be connected to more than one printer at a time.
 */

/*
 * Communication packet specification between client programs.
 *
 * [ input packet ]
 *      header (3byte) : 'pcp' length data
 *      length (2byte) : Size of data
 *      data           : Data (command)
 *
 * [ output packet ]
 *      header (3byte) : 'pcp' length data
 *      length (2byte) : Size of data. When it was 0, show that error
 *                       occurred with the server side. In that event
 *                       data size is always 1 (error code).
 *
 *      error code
 *           0x00 No error (Nothing reply)
 *           0x01 Receive indistinct packet
 *           0x02 Cannot communicate with a printer
 *           0x03 Memory shortage
 */
#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "cbtd.h"
#include "libcbt.h"
#include "cbtd_thread.h"
#include "epson-typdefs.h"


#define ECBD_VERSION "* ecbd is a part of " PACKAGE_STRING

#define ECBD_USAGE "Usage: $ ecbd [-p pidfile]\n\
    -p pidfile\n\
        Use specified file as pid file"


static void cbtd_control (void);
static int prt_connect_libusb (P_CBTD_INFO);
static void init_cbtd (P_CBTD_INFO);
static int init_epson_cbt (P_CBTD_INFO);

int pid_fd = -1;

int
main (int argc, char* argv[])
{
#ifndef _DEBUG
	long pid;
	char buf[255];
	int len;
	int num;
	char default_pid_path[] = PID_PATH;
	int i;
	char *pid_path;

	pid_path = &default_pid_path[0];
	for ( i = 1; i < argc; i++ ) {
		if( ( 0 == strncmp(argv[i], "-p", (strlen("-p")+1)) )
			&& ( argc > i + 1 )
			){
			pid_path = argv[i + 1];
			i++;
		}else if ( (0 == strncmp(argv[i], "-v", (strlen("-v")+1)) )
			|| (0 == strncmp(argv[i], "--version", (strlen("--version")+1)) )
			) {
			fprintf(stderr, "%s\n", ECBD_VERSION);
			return 0;
		} else if ( (0 == strncmp(argv[i], "-u", (strlen("-u")+1)) )
			|| (0 == strncmp(argv[i], "--usage", (strlen("--usage")+1)) )
			) {
			fprintf(stderr, "%s\n", ECBD_USAGE);
			return 0;
		} else if ( (0 == strncmp(argv[i], "-h", (strlen("-h")+1)) )
			|| (0 == strncmp(argv[i], "--help", (strlen("--help")+1)) )
			) {
			fprintf(stderr, "%s\n%s\n", ECBD_VERSION, ECBD_USAGE);
			return 0;
		}
	}

	if (geteuid () != 0)
	{
		fprintf (stderr, "must run as root\n");
		return 1;
	}

	/* start create ecbd.pid file */
	if (-1 == (pid_fd = open(pid_path, O_RDWR|O_CREAT, 0600)))
	{
		fprintf(stderr, "failed to open %s\n", pid_path);
		return 1;
	}
	if (-1 == flock(pid_fd, LOCK_EX|LOCK_NB)) {
	/* pid file already exist */
		fprintf(stderr, "failed to lock %s\n", pid_path);
		return 1;
	}
	fchmod(pid_fd, 0644);
	fcntl(pid_fd, F_SETFD, 1); /* set FD_CLOEXEC */
	/* end create ecbd.pid file */

	/* shift to daemon process */
	if ((pid = fork ()))
	{
		exit (0);
	}
	if (pid < 0)
	{
		perror ("fork() failtd");
		return 1;
	}

	/* write pid to /var/run/ecbd.pid */
	sprintf(buf, "%ld\n", (long)getpid());
	lseek(pid_fd, (off_t)0, SEEK_SET);
	len =  strlen(buf);
	if( (num = write(pid_fd, buf, len)) != len )
	{
		fprintf(stderr,"write() failed:\n");
		return 1;
	}

#endif

	cbtd_control ();
	return 0;
}


/* main thread */
static void
cbtd_control (void)
{
	CBTD_INFO info;
	int set_flags, reset_flags;

	init_cbtd (&info);
	sig_set ();

	while (!is_sysflags (&info, ST_SYS_DOWN))
	{
		for (;;)
		{
			set_flags = 0;
			reset_flags = ST_SYS_DOWN | ST_CLIENT_CONNECT | ST_JOB_PRINTING | ST_JOB_CANCEL;
			if (wait_sysflags (&info, set_flags, reset_flags, 5, WAIT_SYS_AND) == 0) {
				break; // break if (sysflags & reset_flaags) > 0
			}

			if (is_sysflags (&info, ST_DAEMON_WAKEUP))
				reset_sysflags (&info, ST_DAEMON_WAKEUP);
		}

		set_sysflags (&info, ST_DAEMON_WAKEUP);
		/* connect a printer */
		if (prt_connect_libusb (&info) < 0)
			continue;

		/* initialize communication */
		if (init_epson_cbt (&info) == 0)
		{
			// /* thread starting */
			// set_sysflags (&info, ST_PRT_CONNECT);

			// /* check status */
			// for (;;)
			// {
			// 	set_flags = ST_CLIENT_CONNECT | ST_JOB_PRINTING | ST_JOB_CANCEL;
			// 	reset_flags = 0;
			// 	writeLogFile("cbtd_control:break1 wait_sysflags sysflags %d\n",info.sysflags);
			// 	if (wait_sysflags (&info, set_flags, reset_flags, 2, WAIT_SYS_OR) == 0) {
			// 		writeLogFile("cbtd_control:break1\n");
			// 		break;
			// 	}
			// }
			// writeLogFile("cbtd_control:reset_sysflags ST_PRT_CONNECT\n");
			// reset_sysflags (&info, ST_PRT_CONNECT);

			/* thread starting */
			 P_SEM_OBJECT p_semobj = (P_SEM_OBJECT)info.sysflags_critical;
			 int err = 0;
			 assert (p_semobj);
			 err = pthread_mutex_lock (&p_semobj->mutex);
			 if (err != 0) {
				 continue;
			 }
			 info.sysflags |= ST_PRT_CONNECT;
			 err = pthread_cond_broadcast(&p_semobj->cond);
			 assert (err == 0);

			 /* check status */
			 for (;;) {
				set_flags = ST_CLIENT_CONNECT | ST_JOB_PRINTING | ST_JOB_CANCEL;
				reset_flags = 0;
				if (wait_sysflags_not_lock_unlock (&info, set_flags, reset_flags, 2, WAIT_SYS_OR, p_semobj) == 0) {
					writeLogFile("cbtd_control:break\n");
			 		break;  // break if (sysflags & set_flaags) == 0
				}
			 }
			 writeLogFile("cbtd_control:reset_sysflags ST_PRT_CONNECT\n");
			 info.sysflags &= (ST_PRT_CONNECT ^ 0xff);
			 err  = pthread_cond_broadcast(&p_semobj->cond);
			 err += pthread_mutex_unlock(&p_semobj->mutex);
			 assert (err == 0);
		}

		end_epson_cbt (&info);

		if (info.devfd.devfd >= 0)
		{
			writeLogFile("libusb_attach_kernel_driver:\n");
			if (info.devfd.mDevHandle) {
				libusb_release_interface(info.devfd.mDevHandle, info.devfd.mIFnum);
				if (info.devfd.mHasDetachdeKernelDriver) {
					libusb_attach_kernel_driver(info.devfd.mDevHandle, info.devfd.mIFnum);
					info.devfd.mHasDetachdeKernelDriver = false;
				}
				libusb_close(info.devfd.mDevHandle);
				info.devfd.mDevHandle = NULL;
				_DEBUG_MESSAGE("deconnect printer\n");
			}
			
			if (info.devfd.mlibusbContext) {
				libusb_exit(info.devfd.mlibusbContext);
				info.devfd.mlibusbContext = NULL;
				writeLogFile("libusb_exit:\n");
			}
			info.devfd.devfd = -1;
			
			if (!is_sysflags (&info, ST_SYS_DOWN))
				sleep (2);
		}
	}

	/* wait for end of other thread */
	while (info.datatrans_thread_status != THREAD_DOWN
	       || info.comserv_thread_status != THREAD_DOWN)
		sleep (1);

	end_cbtd (&info);
	return;
}

int getDeviceID(libusb_device_handle *devHandle, uint8_t iConfiguration,struct libusb_interface_descriptor interfaceDesc, unsigned char *buf) {
	int err = -1;
	int replySize = 0;
	
	if (devHandle == NULL || buf == NULL) {
		return -1;
	}
	
	memset(buf, 0x00, kDeviceInfoDeviceIDMaxSize);
	
	unsigned char deviceID[kDeviceInfoDeviceIDMaxSize];
	replySize = libusb_control_transfer(devHandle, LIBUSB_ENDPOINT_IN | LIBUSB_REQUEST_TYPE_CLASS | LIBUSB_RECIPIENT_INTERFACE, 0, 0,(((uint16_t)interfaceDesc.bInterfaceNumber) << 8) | interfaceDesc.bAlternateSetting, deviceID, kDeviceInfoDeviceIDMaxSize, 10*1000);
	if(replySize > 0) {
		/*先頭2バイトは長さを表す(big endian)*/
		int length = (int)((deviceID[0] << 8) | (deviceID[1]));
		int acutualSize = length - 2;
		memcpy(buf,deviceID + 2, acutualSize);
		err = 0;
	} else {
		err = -1;
	}
	return err;
}

int deviceIDFormatter(unsigned char *deviceID, const char *keyName, unsigned char *keyValue) {
	if (deviceID == NULL || keyName == NULL) {
		return -1;
	}
	char *keyTop   = strstr((char *)deviceID,keyName);
	if (keyTop == NULL) {
		return -1;
	}
	char *valueEnd = strchr(keyTop,';');
	if (valueEnd == NULL) {
		return -1;
	}
	keyTop = keyTop + strlen(keyName);
	memcpy(keyValue, keyTop, valueEnd - keyTop);
	return 0;
}

int checkFaxoutServiceFromDeviceID(unsigned char *deviceID, const char *keyName) {
	unsigned char buf[kDeviceInfoDeviceIDMaxSize] = {};
	deviceIDFormatter(deviceID, keyName, buf);
	if (buf[0] !='\0') {
		char *topAddress = strstr((char *)buf, kCmdFaxValue);
		if (topAddress != NULL) {
			return 1;
		}
	}
	else {
		return -1;
	}
	return 0;
}

/* serch printer */
int openUSBConnectedEPSONDevice(P_CBTD_INFO p_info) {
	int i, j, k,l;
	int err, numdev;
	libusb_device **pplist;
	struct libusb_device_descriptor desc;
	struct libusb_config_descriptor *pcfgdesc = NULL;
	struct libusb_endpoint_descriptor endpt;
	int *mIFnum  = &p_info->devfd.mIFnum;
	unsigned char *mEpReadNumber = &p_info->devfd.mEpReadNumber;
	unsigned char *mEpWriteNumber = &p_info->devfd.mEpWriteNumber;
	libusb_device_handle **mDevHandle = &p_info->devfd.mDevHandle;
	*mDevHandle = NULL;
	bool *mHasDetachdeKernelDriver    = &p_info->devfd.mHasDetachdeKernelDriver;
	
	writeLogFile("openUSBConnectedEPSONDevice:\n");
	
	err = libusb_init(&p_info -> devfd.mlibusbContext);
	if(err < 0) {
		writeLogFile("openUSBConnectedEPSONDevice:libusb_init err %d\n",err);
		return err;
	}
	
	numdev = libusb_get_device_list(p_info -> devfd.mlibusbContext, &pplist);
	writeLogFile("openUSBConnectedEPSONDevice:numdev %d\n",numdev);
	if(numdev <= 0) {
		writeLogFile("numdev < 0\n");
		goto openLibusbFinish;
	}
	for(i = 0; i < numdev; i++){
		libusb_device    *pdev = pplist[i];
		
		err = libusb_get_device_descriptor(pdev, &desc);
		if(err < LIBUSB_SUCCESS || desc.bNumConfigurations < 1 || desc.idVendor != VENDOR_ID) {
			continue;
		}
		
		//out_log(3, "  epson printer\n");
		
		err = libusb_get_active_config_descriptor(pdev, &pcfgdesc);
		if(err < LIBUSB_SUCCESS) {
			continue;
		}
		
		uint8_t if_class;
		uint8_t if_subclass;
		uint8_t if_protocol;
		
		for(j = 0; j < pcfgdesc->bNumInterfaces; j++) {
			for(k = 0; k < pcfgdesc->interface[j].num_altsetting; k++) {
				if_class    = pcfgdesc->interface[j].altsetting[k].bInterfaceClass;
				if_subclass = pcfgdesc->interface[j].altsetting[k].bInterfaceSubClass;
				if_protocol = pcfgdesc->interface[j].altsetting[k].bInterfaceProtocol;
				
				// Printer IF
				if(if_class == kUSBPrinterInterfaceClass && if_subclass == kUSBPrinterInterfaceSubClass && if_protocol == kUSBPrinterInterfaceProtocol) {
					
					*mIFnum = j;
					int numep = pcfgdesc->interface[j].altsetting[k].bNumEndpoints;
					for(l = 0; l < numep; l++){
						endpt =  pcfgdesc->interface[j].altsetting[k].endpoint[l];
						if((endpt.bmAttributes & LIBUSB_TRANSFER_TYPE_MASK) != LIBUSB_TRANSFER_TYPE_BULK) {
							libusb_free_config_descriptor(pcfgdesc);
							continue;
						}
						
						if(endpt.bEndpointAddress & LIBUSB_ENDPOINT_DIR_MASK){
							*mEpReadNumber = (unsigned char)endpt.bEndpointAddress;
						} else {
							*mEpWriteNumber = (unsigned char)endpt.bEndpointAddress;
						}
					}
					
					if (*mDevHandle == NULL) {
						err = libusb_open(pdev, mDevHandle);
						if(err != LIBUSB_SUCCESS) {
							writeLogFile("err : libusb_open %d",err);
							mDevHandle = NULL;
							goto openLibusbFinish;
						}
					}
					
					//need detach_kernel_driver before get device id (ubuntu12.04)
					if (libusb_kernel_driver_active(*mDevHandle, *mIFnum) == 1) {
						err = libusb_detach_kernel_driver(*mDevHandle, *mIFnum);
						if(err != LIBUSB_SUCCESS) {
							writeLogFile("err : libusb_detach_kernel_driver %d",err);
							goto openLibusbFinish;
						}
						*mHasDetachdeKernelDriver = true;
					}
					
					//Get device ID
					unsigned char buf[kDeviceInfoDeviceIDMaxSize] = {};
					err = getDeviceID(*mDevHandle, pcfgdesc->iConfiguration, pcfgdesc->interface[j].altsetting[k], buf);
					if (err < 0) {
						writeLogFile("openUSBConnectedEPSONDevice :getDeviceID %d\n",err);
						if (*mHasDetachdeKernelDriver) {
							libusb_attach_kernel_driver(*mDevHandle, *mIFnum);
							*mHasDetachdeKernelDriver = false;
						}
						libusb_free_config_descriptor(pcfgdesc);
						continue;
					}
					
					writeLogFile("device id :%s\n",buf);
					//check Fax form device id
					err = checkFaxoutServiceFromDeviceID(buf, kModelCommandNumberKey);
					if (err < 0 || err == 1) {
						writeLogFile("openUSBConnectedEPSONDevice :checkFaxoutServiceFromDeviceID %d\n",err);
						if (*mHasDetachdeKernelDriver) {
							libusb_attach_kernel_driver(*mDevHandle, *mIFnum);
							*mHasDetachdeKernelDriver = false;
						}
						libusb_free_config_descriptor(pcfgdesc);
						continue;
					}
					
					if (parameter_update(p_info,buf) == 1) {
						writeLogFile("openUSBConnectedEPSONDevice:parameter_update err\n");
						goto openLibusbFinish;
					}
					
					//claim interface
					int tryCount = 0;
					do {
						err = libusb_claim_interface(*mDevHandle, *mIFnum);
						if (err == LIBUSB_SUCCESS) break;
						usleep(1000 * 100);
						tryCount ++;
						writeLogFile("try claim %d\n", tryCount);
					} while (tryCount < 50);
					
					if(err != LIBUSB_SUCCESS) {
						writeLogFile("err : libusb_claim_interface %d",err);
						goto openLibusbFinish;
					}
					
					libusb_free_config_descriptor(pcfgdesc);
					libusb_free_device_list(pplist, 1);
					return 0;
				}
			}
		}
	}
openLibusbFinish:
	if (*mHasDetachdeKernelDriver) {
		libusb_attach_kernel_driver(*mDevHandle, *mIFnum);
		*mHasDetachdeKernelDriver = false;
	}
	if (*mDevHandle) {
		libusb_close(*mDevHandle);
		*mDevHandle = NULL;
	}
	if (p_info -> devfd.mlibusbContext) {
		libusb_exit(p_info -> devfd.mlibusbContext);
		p_info -> devfd.mlibusbContext = NULL;
	}
	if (pcfgdesc) {
		libusb_free_config_descriptor(pcfgdesc);
		pcfgdesc = NULL;
	}
	if (pplist) {
		libusb_free_device_list(pplist, 1);
		pplist = NULL;
	}
	return -1;
}


/* connect a printer */
static int
prt_connect_libusb (P_CBTD_INFO p_info)
{
	writeLogFile("prt_connect_libusb:\n");
	int *fd = &p_info->devfd.devfd;
	int i;
	int error = 1;

	if (is_sysflags (p_info, ST_SYS_DOWN)) {
		writeLogFile("prt_connect_libusb:ST_SYS_DOWN\n");
		return -1;
	}
	
	 for (i = 0; i < 5; i++)
	{
	    error = openUSBConnectedEPSONDevice(p_info);

		if (error < 0 || p_info->devfd.mDevHandle == NULL)
		{
			writeLogFile("prt_connect_libusb:openUSBConnectedEPSONDevice %d\n",error);
			*fd = -1;
			usleep (50000);
		}
		else
		{
			*fd = 1;
			_DEBUG_MESSAGE("connect printer\n");  
			return *fd;
		}
	}
	_DEBUG_MESSAGE("waiting.....\n");
	sleep (3);
	return *fd;
}


/* initialize process */
static void
init_cbtd (P_CBTD_INFO p_info)
{
	writeLogFile("init_cbtd:\n");
	memset (p_info, 0, sizeof (CBTD_INFO));

	/* default setup */
	strcpy (p_info->infifo_path, FIFO_PATH);
	p_info->comsock_port = DAEMON_PORT;

	LIBUSB_INFO usbInfo;
	usbInfo.devfd          = -1;
	usbInfo.mDevHandle     = NULL;
	usbInfo.mEpReadNumber  = '\0';
	usbInfo.mEpWriteNumber = '\0';
	usbInfo.mIFnum         = -1;
	usbInfo.mlibusbContext = NULL;
	usbInfo.mHasDetachdeKernelDriver = false;
	p_info->devfd = usbInfo;

	p_info->sysflags = 0;
	p_info->sysflags_critical = init_critical ();

	p_info->ecbt_accsess_critical = init_critical ();
	assert (p_info->sysflags_critical != NULL
		&& p_info->ecbt_accsess_critical != NULL);

	p_info->datatrans_thread_status = THREAD_RUN;
	p_info->comserv_thread_status = THREAD_RUN;

	p_info->datatrans_thread
		= init_thread (CBTD_THREAD_STACK_SIZE,
			       (void *)datatrans_thread,
			       (void *)p_info);

	p_info->comserv_thread
		= init_thread (CBTD_THREAD_STACK_SIZE,
			       (void *)comserv_thread,
			       (void *)p_info);

	assert (p_info->datatrans_thread != NULL
		&& p_info->comserv_thread != NULL);

	return;
}


/* end of process */
void
end_cbtd (P_CBTD_INFO p_info)
{
	writeLogFile("end_cbtd:\n");
	if (p_info->datatrans_thread)
		delete_thread (p_info->datatrans_thread);

	if (p_info->comserv_thread)
		delete_thread (p_info->comserv_thread);


	if (p_info->sysflags_critical)
		delete_critical (p_info->sysflags_critical);

	if (p_info->ecbt_accsess_critical)
		delete_critical (p_info->ecbt_accsess_critical);

	return;
}


/* initialize CBT */
static int
init_epson_cbt (P_CBTD_INFO p_info)
{
	writeLogFile("init_epson_cbt:\n");
	start_ecbt_engine ();
	return open_port_driver (p_info);
}


/* end of CBT */
int
end_epson_cbt (P_CBTD_INFO p_info)
{
	writeLogFile("end_epson_cbt:\n");
	int err = 0;

	err = close_port_driver (p_info);
	end_ecbt_engine ();
	
	return err;
}
