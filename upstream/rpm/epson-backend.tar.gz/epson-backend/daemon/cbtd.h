/*
 * Copyright (C) Seiko Epson Corporation 2014.
 *
 * This file is part of the `ecbd' program.
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * As a special exception, AVASYS CORPORATION gives permission
 * to link the code of this program with the `cbt' library and
 * distribute linked combinations including the two.  You must obey
 * the GNU General Public License in all respects for all of the
 * code used other then `cbt'.
 */
#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#ifndef __CBTD_H__
#define __CBTD_H__

#ifndef _DEBUG
#define NOEBUG
#endif

#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <libusb-1.0/libusb.h>
#include "cbtd_def.h"

#define CBTD_THREAD_STACK_SIZE 0x4000 /* unused */

#define PRT_STATUS_MAX 256	/* maximum size of printer status strings */
#define CONF_BUF_MAX 100	/* maximum size of configuration strings */
#define PID_PATH "/var/run/ecbd.pid"

#define kUSBPrinterInterfaceClass    LIBUSB_CLASS_PRINTER
#define kUSBPrinterInterfaceSubClass 0x01
#define kUSBPrinterInterfaceProtocol 0x02
#define VENDOR_ID    0x04b8
#define kModelNameKey             "MDL:"
#define kModelCommandNumberKey    "CMD:"
#define kCmdFaxValue              "FAXoutService"
#define kDeviceInfoDeviceIDMaxSize    512
#define kLogFilePath "/tmp/ecbd_log.txt"

//#define _DEBUG_LOG
#ifdef _DEBUG_LOG
#define writeLogFile(...) do { struct timeval tm; gettimeofday(&tm,NULL);FILE *file = fopen(kLogFilePath, "a");if (file != NULL) {fprintf(file,"%ld : ",tm.tv_sec * 1000 + tm.tv_usec / 1000);fprintf(file,__VA_ARGS__);fclose(file);} else fprintf(stderr,"file open err\n"); } while(0)
#else
#define writeLogFile(...)
#endif

typedef struct _LIBUSB_INFO
{
	int devfd;		/* device file descriptor */
/* libusb */
	libusb_device_handle *mDevHandle;
	int mIFnum;                        // device interface number
	unsigned char mEpReadNumber;       // read enpoint
    unsigned char mEpWriteNumber;      // write endpoint
	libusb_context *mlibusbContext;
	bool mHasDetachdeKernelDriver;
} LIBUSB_INFO;

typedef struct _CBTD_INFO
{
	char printer_name[CONF_BUF_MAX]; /* the printer title that is set with lpr */
	char devprt_path[CONF_BUF_MAX]; /* open device path */
	char infifo_path[CONF_BUF_MAX]; /* fifo path */
	unsigned int comsock_port; /* INET socket port */
	LIBUSB_INFO devfd;		/* device file descriptor */

	char prt_status[PRT_STATUS_MAX]; /* printer status */
	int prt_status_len;	/* size of printer status strings */
	long status_post_time; /* the time that updated prt_status in the last */

	int sysflags;		/* CBTD status flags */ 
	void* sysflags_critical;

/* Parent thread uses status of each thread for authentication.
   Not need to manage it with semaphore. */
	void* datatrans_thread;
	int datatrans_thread_status;
	void* comserv_thread;
	int comserv_thread_status;

/* CBT control */
	void* ecbt_handle;
	void* ecbt_accsess_critical;

	int sleepTime;
} CBTD_INFO, *P_CBTD_INFO;

/* Status of thread */
enum _CBTD_THREAD_STATUS_NUMBERS {
	THREAD_RUN = 0,
	THREAD_SLEEP,
	THREAD_DOWN
};

/* structure for semaphore */
typedef struct _SEM_OBJECT
{
  pthread_mutex_t mutex;
  pthread_cond_t cond;
  int status_flag;
} SEM_OBJECT, *P_SEM_OBJECT;


/* Status of a system */
enum _CBTD_SYSTEM_FLAGS {
	ST_SYS_DOWN = 1,	 /* 00000001  system is in the middle of end process */

	ST_DAEMON_WAKEUP = 2,    /* 00000010  system works */
	ST_PRT_CONNECT = 4,      /* 00000100  connected to a printer */

	ST_CLIENT_CONNECT = 8,   /* 00001000  presence of connection from a client */
	ST_JOB_PRINTING = 16,	 /* 00010000  print it */
	ST_JOB_CANCEL = 32,      /* 00100000  canceling print job */
	ST_JOB_CANCEL_NO_D4 = 64 /* 01000000  wait for reset of a printer */
};

/* Maintenance box status */
enum _MAINTENANCE_BOX_STATUS
{
	ECB_MBOX_ST_NORMAL = 0,
	ECB_MBOX_ST_NEARFULL = 1,
	ECB_MBOX_ST_FULL = 2,
	ECB_MBOX_ST_NOTPRESENT = -1,
	ECB_MBOX_ST_FAIL = -3,
	ECB_MBOX_ST_NOREAD = -4
};


void end_cbtd (P_CBTD_INFO);
int end_epson_cbt (P_CBTD_INFO);
void sig_set (void);
int parameter_setup (P_CBTD_INFO);
int parameter_update (P_CBTD_INFO, unsigned char *newDeviceID);
void datatrans_thread (P_CBTD_INFO);
void comserv_thread (P_CBTD_INFO);


#endif /* __CBTD_H__ */
