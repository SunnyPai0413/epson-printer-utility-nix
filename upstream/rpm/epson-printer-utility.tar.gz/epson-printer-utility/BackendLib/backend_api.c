/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <sys/socket.h>
#include "backend_api.h"
#include "ekpcom.h"

#define TIME_OUT 3

typedef struct INK_NODE {
  unsigned long id;
  int rest;
  struct INK_NODE *next;
} InkNode, *InkList;


static ECB_PRINTER_STS 	printer_status;
static ECB_PRINTER_ERR 	error_code;
static ECB_INT32   		ink_num;
static ECB_INT32   		colors[ECB_INK_NUM];
static ECB_INT32   		inklevel[ECB_INK_NUM];
static ECB_PAPER_COUNT  papercount;
static ECB_BOOL		showInkInfo;
static ECB_BOOL		showInkLow;
static InkList ink_list;

enum Inkbox_Id
{
    ECB_COLOR_BLACK,
    ECB_COLOR_CYAN,
    ECB_COLOR_MAGENTA,
    ECB_COLOR_YELLOW,
    ECB_COLOR_LIGHTCYAN,
    ECB_COLOR_LIGHTMAGENTA,
    ECB_COLOR_LIGHTYELLOW,
    ECB_COLOR_DARKYELLOW,
    ECB_COLOR_LIGHTBLACK,
    ECB_COLOR_RED,
    ECB_COLOR_VIOLET,
    ECB_COLOR_MATTE_BLACK,
	ECB_COLOR_LIGHTLIGHTBLACK,
    ECB_COLOR_PHOTO_BLACK,
    ECB_COLOR_CLEAR,
    ECB_COLOR_GRAY,
    ECB_COLOR_UNKNOWN,

	/* add ver5.0*/
    ECB_COLOR_BLACK2,
	ECB_COLOR_ORANGE,
	ECB_COLOR_GREEN,
	ECB_COLOR_WHITE,
	ECB_COLOR_CLEAN
};


enum Inkbox_Id 
inkbox_get_inkid( unsigned long id )
{
	enum Inkbox_Id color;

	switch (id) {
	case 0x1101:
	case 0x1140:
		color = ECB_COLOR_BLACK; break;
	case 0x3202:
		color = ECB_COLOR_CYAN; break;
	case 0x4304:
		color = ECB_COLOR_MAGENTA; break;
	case 0x5408:
		color = ECB_COLOR_YELLOW; break;
	case 0x6210:
		color = ECB_COLOR_LIGHTCYAN; break;
	case 0x7320:
		color = ECB_COLOR_LIGHTMAGENTA; break;
	case 0x9440:
		color = ECB_COLOR_DARKYELLOW; break;
	case 0xA140:
		color = ECB_COLOR_PHOTO_BLACK; break;
	case 0xB140:
	case 0xB101:
		color = ECB_COLOR_MATTE_BLACK; break;
	case 0xC140:
		color = ECB_COLOR_LIGHTBLACK; break;
	case 0x9020:
		/* 2004.01.21 Added Red */
		color = ECB_COLOR_RED; break;
	case 0xA040:
		/* 2004.01.21 Added Violet */
		color = ECB_COLOR_VIOLET; break;
	case 0xB080:
		/* 2004.01.21 Added Clear */
		color = ECB_COLOR_CLEAR; break;
	case 0xD010:
		color = ECB_COLOR_ORANGE; break;
		
	default:
		/* UNKNOWN COLOR */
		color = ECB_COLOR_UNKNOWN; break;
	}
	return	color;
}


static int hextoi(char hex)
{
	int value;
	switch(hex){
		case '0':   
			value = 0;
			break;
		case '1':   
			value = 1;
			break;
		case '2':
		    value = 2;
			break;
		case '3':
		    value = 3;
			break;
		case '4':
		    value = 4;
			break;
		case '5':
		    value = 5;
			break;
		case '6':
		    value = 6;
			break;
		case '7':
		    value = 7;
			break;
		case '8':
		    value = 8;
			break;
		case '9':
		    value = 9;
			break;
		case 'A':
		case 'a':
		    value = 10;
			break;
		case 'B':
		case 'b':
		    value = 11;
			break;
		case 'C':
		case 'c':
		    value = 12;
			break;
		case 'D':
		case 'd':
		    value = 13;
			break;
		case 'E':
		case 'e':
		    value = 14;
			break;
		case 'F':
		case 'f':
		    value = 15;
			break;
		default :
			value = -1;
	}		
		return value;
}

#define EPS_INK_NORMALIZE_LEVEL (5)
int    serInkLevelNromalize (

		int level

){
	int norm = 0;
	if (EPS_INK_NORMALIZE_LEVEL > 3 && (level >= 1) && (level <= 3)) {
		norm = 1;
	} else{
		norm = (level / EPS_INK_NORMALIZE_LEVEL) * EPS_INK_NORMALIZE_LEVEL;
		if(level % EPS_INK_NORMALIZE_LEVEL){
			norm += EPS_INK_NORMALIZE_LEVEL;
		}
	}
	return norm;
}


static ECB_PRINTER_STS ReadStatuslogfile (InkList *, ECB_PRINTER_ERR* errorCode);
static void ink_list_delete (InkList);

static ECB_PRINTER_STS
ReadStatuslogfile (InkList *list, ECB_PRINTER_ERR* errorCode)
{
  char *lpInk, *lpSts, *lpErr, *lpWR, *lpCC, *lpMC, *lpWC, *lpAC, *lpCB, *lpMB, *lpCS;
  char lpReply[1024], StsCode[3], ErrCode[3], WarningCode[3];
  char get_status_command[] = { 's', 't', 0x01, 0x00, 0x01 };
  int com_len, rep_len;

  clock_t start, stop;

  start = time(NULL);
RETRY:

  /* Initialization */
  StsCode[2] = 0;
  ErrCode[2] = 0;
  *list = NULL;


  com_len = sizeof (get_status_command);
  rep_len = 1024;
  /* Log file reading */

  if (sock_write (get_status_command, &com_len) < 0)
  {
    if (sock_reopen () < 0)
    {
      return ECB_DAEMON_DOWN;
    }
    return ECB_DAEMON_NO_REPLY;
  }
  
  sock_read (lpReply, &rep_len);

  if (rep_len == 0)
  {
    double diff;
	stop = time(NULL);
	diff = difftime(stop, start);
	if (diff < TIME_OUT ) goto RETRY;

    return ECB_DAEMON_NO_REPLY;
  }

  /* Ink kind analysis */
  lpInk = strstr (lpReply, "INK:");

  if (lpInk){
    char ic[7] = "0x";
    InkNode *prev = NULL;

    lpInk += 4;     /* skip "INK:" */
    while (*lpInk != ';') {
      InkNode *node;

      node = (InkNode *)calloc(1, sizeof(InkNode));
      if (!node) {
        return ECB_DAEMON_NO_REPLY;
      }

      memcpy(ic + 2, lpInk, 4);
      *(ic + 6) = '\0';
      node->id = strtol(ic, (char **)NULL, 16);

      if (prev) {
        prev->next = node;
        prev = prev->next;
      } else {
        prev = node;
        *list = prev;
      }
      lpInk += 4;
      if (*lpInk == ',') {
        lpInk++;
      }
      node = node->next;
    }
  }else{
    char snink[3];
    int nink, i;
    InkNode *prev = NULL;

    /* 2004.03.18           */
    /* INK:... not reply    */
    /* check "AI:CW:"       */
    lpInk = strstr (lpReply, "AI:CW:");
    if( !lpInk )
      return ECB_DAEMON_NO_REPLY;
    /* Found!               */
    lpInk += 6;     /* skip "AI:CW:" */

    /* get no. of ink */
    sprintf( snink, "%.2s", lpInk);
    nink = atoi( snink );

    lpInk += 2;

    /* setup ink list */
    for( i = 0; i < nink ; i++ ){
      InkNode *node;

      node = (InkNode *)calloc(1, sizeof(InkNode));
      if (!node) {
        return ECB_DAEMON_NO_REPLY;
      }

      switch( i ){
      case    0: /* black */
        node->id = 0x1101;break;
      case    1: /* cyan */
        node->id = 0x3202;break;
      case    2: /* yellow */
        node->id = 0x4304;break;
      case    3: /* magenta */
        node->id = 0x5408;break;
      case    4: /* light cyan */
        node->id = 0x6210;break;
      case    5: /* light magenta */
        node->id = 0x7320;break;
      case    6: /* dark yellow */
        node->id = 0x9440;break;
      case    7: /* light black */
        node->id = 0x1140;break;
      default :
        node->id = 0x0;break;
      }

      if (prev) {
        prev->next = node;
        prev = prev->next;
      } else {
        prev = node;
        *list = prev;
      }
      node = node->next;
    }
  }

  /* Ink residual quantity analysis */
  lpInk = strstr(lpReply, "IQ:");

  if(lpInk){
    char ink[3];
    char *stopstring;
    InkNode *node = *list;

    lpInk += 3;
    memset (ink, 0, 3);


   int ink_no = 0;
   while (node)
    {
      strncpy(ink, lpInk, 2);
      node->rest = (int)strtol (ink, &stopstring, 16);

      colors[ink_no] = inkbox_get_inkid(node->id);
      inklevel[ink_no] = node->rest;
      ink_no++;     

      node = node->next;
      lpInk +=2;
      if (*lpInk == ';') break;
    }
   ink_num = ink_no;
  }
	
// lpReply = ST:03;ER:01;WR:01;CS:11;IQ:69696969;INK:1101540843043202;CC:32000000;MC:04000000;WC:00000000;AC:00000000;CB:00000000;MB:00000000;

  /* Characteristic status code */
  lpCS = strstr(lpReply, "CS:");

  if(lpCS){
	showInkInfo =  hextoi(lpCS[3]);
	showInkLow =   hextoi(lpCS[4]);
  }else{
	showInkInfo =  1; // 1: Show Ink Information
	showInkLow =  1;  // 1: Show Ink Low
    }	


  /* Color Printed Number */
  lpCC = strstr(lpReply, "CC:");
  if(lpCC){
	papercount.color =  (hextoi(lpCC[3])*16 + hextoi(lpCC[4])) + (hextoi(lpCC[5])*16 + hextoi(lpCC[6]))*256 + (hextoi(lpCC[7])*16 + hextoi(lpCC[8]))*(256^2) + (hextoi(lpCC[9])*16 + hextoi(lpCC[10]))*(256^3);
  }else{
	papercount.color = -1;
  }

  /* Monochrome Printed Number */
  lpMC = strstr(lpReply, "MC:");
  if(lpMC){
	papercount.monochrome =  (hextoi(lpMC[3])*16 + hextoi(lpMC[4])) + (hextoi(lpMC[5])*16 + hextoi(lpMC[6]))*256 + (hextoi(lpMC[7])*16 + hextoi(lpMC[8]))*(256^2) + (hextoi(lpMC[9])*16 + hextoi(lpMC[10]))*(256^3);

//	printf("mono=%d\n", papercount.monochrome);


  }else{
	papercount.monochrome = -1;
  }

  /* Blank Printed Number */
  lpWC = strstr(lpReply, "WC:");
  if(lpWC){
	papercount.blank =  (hextoi(lpWC[3])*16 + hextoi(lpWC[4])) + (hextoi(lpWC[5])*16 + hextoi(lpWC[6]))*256 + (hextoi(lpWC[7])*16 + hextoi(lpWC[8]))*(256^2) + (hextoi(lpWC[9])*16 + hextoi(lpWC[10]))*(256^3);

  }else{
    papercount.blank = -1;
  }

  /* ADF Scanned Number */
  lpAC = strstr(lpReply, "AC:");
  if(lpAC){
	papercount.adf =  (hextoi(lpAC[3])*16 + hextoi(lpAC[4])) + (hextoi(lpAC[5])*16 + hextoi(lpAC[6]))*256 + (hextoi(lpAC[7])*16 + hextoi(lpAC[8]))*(256^2) + (hextoi(lpAC[9])*16 + hextoi(lpAC[10]))*(256^3);

  }else{
    papercount.adf = -1;
  }

  /* Color Bordereless Printed Number */
  lpCB = strstr(lpReply, "CB:");
  if(lpCB){
	papercount.color_borderless =  (hextoi(lpCB[3])*16 + hextoi(lpCB[4])) + (hextoi(lpCB[5])*16 + hextoi(lpCB[6]))*256 + (hextoi(lpCB[7])*16 + hextoi(lpCB[8]))*(256^2) + (hextoi(lpCB[9])*16 + hextoi(lpCB[10]))*(256^3);

  }else{
    papercount.color_borderless = -1;
  }

  /* Monochrome Bordereless Printed Number */
  lpMB = strstr(lpReply, "MB:");
  if(lpMB){
	papercount.monochrome_borderless =  (hextoi(lpMB[3])*16 + hextoi(lpMB[4])) + (hextoi(lpMB[5])*16 + hextoi(lpMB[6]))*256 + (hextoi(lpMB[7])*16 + hextoi(lpMB[8]))*(256^2) + (hextoi(lpMB[9])*16 + hextoi(lpMB[10]))*(256^3);

  }else{
    papercount.monochrome_borderless = -1;
  }

  *errorCode = ECB_PRNERR_NOERROR;

  /* Status analysis */
  lpSts = strstr(lpReply, "ST:");
  if(lpSts){
    strncpy(StsCode, lpSts + 3, 2);

    if(!strcmp(StsCode, "00")){

      /* Error status analysis */
      lpErr = strstr(lpReply, "ER:");
#if DEBUG
      fprintf(stderr, "error code = %s\n", lpErr);
#endif

      if(lpErr){
        strncpy(ErrCode, lpErr + 3, 2);
	*errorCode = ECB_PRNERR_GENERAL;
        //fprintf(stderr, "error code = %s\n", ErrCode);
        if(!strcmp(ErrCode, "00")) *errorCode = ECB_PRNERR_FATAL;
        if(!strcmp(ErrCode, "01")) *errorCode = ECB_PRNERR_INTERFACE;
        if(!strcmp(ErrCode, "02")) *errorCode = ECB_PRNERR_COVEROPEN;
        if(!strcmp(ErrCode, "04")) *errorCode = ECB_PRNERR_PAPERJAM;
        if(!strcmp(ErrCode, "05")) *errorCode = ECB_PRNERR_INKOUT;
        if(!strcmp(ErrCode, "06")) *errorCode = ECB_PRNERR_PAPEROUT;
        if(!strcmp(ErrCode, "0A")) *errorCode = ECB_PRNERR_SIZE_TYPE_PATH;
        if(!strcmp(ErrCode, "0C")) *errorCode = ECB_PRNERR_SIZE_TYPE_PATH;
        if(!strcmp(ErrCode, "10")) *errorCode = ECB_PRNERR_MBOX_FULL;
        if(!strcmp(ErrCode, "12")) *errorCode = ECB_PRNERR_DOUBLEFEED;
        if(!strcmp(ErrCode, "16")) *errorCode = ECB_PRNERR_NOT_CLEANING;
        if(!strcmp(ErrCode, "17")) *errorCode = ECB_PRNERR_PAPERCONFIG;
        if(!strcmp(ErrCode, "18")) *errorCode = ECB_PRNERR_PAPERSLANT;
        if(!strcmp(ErrCode, "1A")) *errorCode = ECB_PRNERR_INKCOVEROPEN;
        if(!strcmp(ErrCode, "22")) *errorCode = ECB_PRNERR_LFP_NOMAINTENANCETANK1;
        if(!strcmp(ErrCode, "28")) *errorCode = ECB_PRNERR_FAILCLEANING;
        if(!strcmp(ErrCode, "29")) *errorCode = ECB_PRNERR_NOTRAY;
        if(!strcmp(ErrCode, "2A")) *errorCode = ECB_PRNERR_CARDLOADING;
        if(!strcmp(ErrCode, "2B")) *errorCode = ECB_PRNERR_CDDVDCONFIG;
        if(!strcmp(ErrCode, "2C")) *errorCode = ECB_PRNERR_CARTRIDGEOVERFLOW;
        if(!strcmp(ErrCode, "2F")) *errorCode = ECB_PRNERR_BATTERYVOLTAGE;
        if(!strcmp(ErrCode, "30")) *errorCode = ECB_PRNERR_BATTERYTEMPERATURE;
        if(!strcmp(ErrCode, "31")) *errorCode = ECB_PRNERR_BATTERYEMPTY;
        if(!strcmp(ErrCode, "32")) *errorCode = ECB_PRNERR_SHUTOFF;
        if(!strcmp(ErrCode, "33")) *errorCode = ECB_PRNERR_NOT_INITIALFILL;
        if(!strcmp(ErrCode, "34")) *errorCode = ECB_PRNERR_PRINTPACKEND;
        if(!strcmp(ErrCode, "37")) *errorCode = ECB_PRNERR_SCANNEROPEN;
        if(!strcmp(ErrCode, "38")) *errorCode = ECB_PRNERR_CDRGUIDEOPEN;
        if(!strcmp(ErrCode, "41")) *errorCode = ECB_PRNERR_MAINTE_REQUIRED;
        if(!strcmp(ErrCode, "44")) *errorCode = ECB_PRNERR_CDRGUIDEOPEN;
        if(!strcmp(ErrCode, "45")) *errorCode = ECB_PRNERR_CDREXIST_MAINTE;
        if(!strcmp(ErrCode, "4B")) *errorCode = ECB_PRNERR_DRIVER_MISMATCH;
        if(!strcmp(ErrCode, "55")) *errorCode = ECB_PRNERR_MEDIA_ERROR;
        if(!strcmp(ErrCode, "58")) *errorCode = ECB_PRNERR_NOZZELECHECK_RECOMMEND;
        if(!strcmp(ErrCode, "5E")) *errorCode = ECB_PRNERR_NOT_CLEANING;
        if(!strcmp(ErrCode, "72")) *errorCode = ECB_PRNERR_WAITING_PAPER_SET;
        if(!strcmp(ErrCode, "7F")) *errorCode = ECB_PRNERR_READYPRINT_SERVICE;
        if(!strcmp(ErrCode, "87")) *errorCode = ECB_PRNERR_PAPER_LOAD_INCORRECT;
        if(!strcmp(ErrCode, "88")) *errorCode = ECB_PRNERR_CANNOT_NOZZELE_CLOGGING;
        if(!strcmp(ErrCode, "89")) *errorCode = ECB_PRNERR_CANNOT_NOZZELE_CLOGGING;
        if(!strcmp(ErrCode, "8B")) *errorCode = ECB_PRNERR_NOZZELECHECK_RECOMMEND;
        if(!strcmp(ErrCode, "8C")) *errorCode = ECB_PRNERR_NOZZELECHECK_RECOMMEND;
      }//if(lpErr){
      
	  return ECB_PRNST_ERROR;
    } // StsCode =="00"

  /* Warning status analysis */
  lpWR = strstr(lpReply, "WR:");
  if(lpWR){
    strncpy(WarningCode, lpSts + 3, 2);
    if(!strcmp(WarningCode, "00")) *errorCode = ECB_PRNWARN_PAPERLOW;
    if(!strcmp(WarningCode, "20")) *errorCode = ECB_PRNWARN_MBOX_NEAREND;
    if(!strcmp(WarningCode, "21")) *errorCode = ECB_PRNWARN_MAINT_REQUIRED;
    if(!strcmp(WarningCode, "45")) *errorCode = ECB_PRNWARN_CHECK_NOZZLE;
    if(!strcmp(WarningCode, "B0")) *errorCode = ECB_PRNWARN_CUTTRASH_FULL;
 
    return ECB_PRNST_IDLE;
  }//if(lpWR)

	if (*errorCode != ECB_PRNERR_NOERROR) return ECB_PRNST_ERROR;

#if DEBUG
    /* Debug */
    fprintf(stderr, "status code = %s\n", StsCode);
#endif

//	*errorCode = ECB_PRNERR_NOERROR;

    if(!strcmp(StsCode, "01")) return ECB_PRNST_BUSY;
    if(!strcmp(StsCode, "02")) return ECB_PRNST_PRINTING;
    if(!strcmp(StsCode, "03")) return ECB_PRNST_BUSY;
    if(!strcmp(StsCode, "04")) return ECB_PRNST_IDLE;
    if(!strcmp(StsCode, "07")) return ECB_PRNST_BUSY;
    if(!strcmp(StsCode, "08")) {
	*errorCode = ECB_PRNERR_FACTORY;
	return ECB_PRNST_ERROR;
    }
    if(!strcmp(StsCode, "0A")) {
	*errorCode = ECB_PRNERR_SHUTDOWN;
	return ECB_PRNST_ERROR;
    }

    if(!strcmp(StsCode, "CN")) return ECB_DAEMON_PRINTER_RESET;
  }

  return ECB_DAEMON_NO_REPLY;
}

static void
connect_daemon()
{
  /* Renewal of ink residual quantity */
  printer_status = ReadStatuslogfile(&ink_list, &error_code);
  ink_list_delete(ink_list);
  return;
}


static void
ink_list_delete (InkList list)
{
  InkNode *node;

  while (list) {
    node = list->next;
    free(list);
    list = node;
  }
  return;
}

/* -----------------------------------------------------------------------------*/
/*             Definition of API Functions                                      */
/*                                                                              */
/* -----------------------------------------------------------------------------*/

int Init_Lib(void){

	return sock_open ();

}

void Close_Lib(void){

	sock_close ();

 	return;
}



void Cancel_Job(void){

	char cancel_command[]="cancel";
	char di_command[]={'d','i',0x01, 0x00, 0x01};
	int len;

	len = strlen (cancel_command);
	sock_write_abandon_reply (cancel_command, &len);

	len = sizeof (di_command);
	sock_write (di_command, &len);

 	return;
}

void Resume_Job(void){

	char feedin_command[]={'p','e',0x01, 0x00, 0x01};
	int len;

	len = sizeof (feedin_command);
	sock_write_abandon_reply (feedin_command, &len);

 	return;
}


ECB_PRINTER_ERR Nozzle_Check(void){

	char nozzlecheck_command[]="nozzlecheck";
	int len;
	ECB_PRINTER_ERR err = ECB_PRNERR_NOERROR;

	len = strlen (nozzlecheck_command);
	err = (ECB_PRINTER_ERR)sock_write_abandon_reply (nozzlecheck_command, &len);

	if (err == 1){
		err = ECB_PRNERR_COMM;
	}

 	return err;

}

ECB_PRINTER_ERR Head_Cleaning(void){

    char headcleaning_command[]="headcleaning";
	int len;
	ECB_PRINTER_ERR err = ECB_PRNERR_NOERROR;

	len = strlen (headcleaning_command);
	err = (ECB_PRINTER_ERR)sock_write_abandon_reply (headcleaning_command, &len);

	if (err == 1){
		err = ECB_PRNERR_COMM;
	}

 	return err;

}


ECB_PRINTER_STS Get_Status (ECB_STATUS* status)
{

  int i;
  printer_status = ECB_DAEMON_NO_ERROR;
  ink_num = 0;
  for(i=0; i< ECB_INK_NUM; i++){
  	colors[i] = 0;
	inklevel[i] = 0;
  }

  ECB_PRINTER_STS ret = ECB_DAEMON_NO_ERROR; 

  connect_daemon();

  status->printerStatus = printer_status;
  status->errorCode = error_code;

  if(printer_status == ECB_DAEMON_NO_REPLY) return ECB_DAEMON_NO_REPLY;

  status->ink_num = ink_num;
  
  for(i=0; i< ink_num; i++){
  	status->colors[i] = colors[i];
	status->inklevel[i] = inklevel[i];

	switch( status->inklevel[i] ){
		case 'w':
		case 'r':
			status->inkstatus[i] = ECB_INK_ST_FAIL;
			break;
		case 'n':
			status->inkstatus[i] = ECB_INK_ST_NOTPRESENT;
			break;
		case 'i':
			status->inkstatus[i] = ECB_INK_ST_NOREAD;
			break;
		case 'g':
			status->inkstatus[i] = ECB_INK_ST_NOTAVAIL;
			break;			
		default:
			if (status->inklevel[i] > 100 || status->inklevel[i] < 0)
			{
				status->inkstatus[i] = ECB_INK_ST_FAIL;
			}else{

                status->inklevel[i] = serInkLevelNromalize( status->inklevel[i] );

                if( status->inklevel[i] == 0) {		
					if(ECB_PRNERR_INKOUT == status->errorCode){
							status->inkstatus[i] = ECB_INK_ST_END;
					}
	 			}else if( status->inklevel[i] >= 1 && status->inklevel[i] <= INKLOW) {		
							status->inkstatus[i] = ECB_INK_ST_LOW;
				}else{
							status->inkstatus[i] = ECB_INK_ST_NORMAL;
				}

			}
		}
       }

	status->paper_count.color = papercount.color;
	status->paper_count.monochrome = papercount.monochrome;
	status->paper_count.blank = papercount.blank;
	status->paper_count.adf = papercount.adf;
	status->paper_count.color_borderless = papercount.color_borderless;
	status->paper_count.monochrome_borderless = papercount.monochrome_borderless;

	status->showInkInfo = showInkInfo;
	status->showInkLow = showInkLow;

  return ret;
}

ECB_INK_RESET_STS Reset_Ink_Counter(int ink){
   char rbuf[128];

	char resetink_command[]={'r','i',0x02, 0x00, 0x00, ink};
	int len, rsize;

	len = sizeof (resetink_command);
	sock_write_with_reply (resetink_command, &len, rbuf, &rsize);


    if (rsize <= 0) {
		return ECB_INK_RESET_COMM_ERROR;
	}

	if(strncmp(rbuf + 6 , "OK", 2) == 0){
		return ECB_INK_RESET_OK;
	}else if(strncmp(rbuf + 6 , "NA", 2) == 0){
		return ECB_INK_RESET_NA;
	}else if(strncmp(rbuf + 6 , "BUSY", 4) == 0){
		return ECB_INK_RESET_BUSY;
	}
	
	return ECB_INK_RESET_COMM_ERROR;

}

int Get_Printer_Info(ECB_PRINTER* printer){

	char getdeviceid_command[]="getdeviceid";
	int len, rsize;

	char deviceid[256];

    clock_t start, stop;

    start = time(NULL);


	while(1){
		len = sizeof (getdeviceid_command);
		sock_write_with_reply (getdeviceid_command, &len, deviceid, &rsize);

		double diff;
		stop = time(NULL);
		diff = difftime(stop, start);
		if ((diff > TIME_OUT) || (rsize > 0) ) break;

	}

	if (rsize == 0) return 0;

	deviceid[rsize]=0;

	char *manufacture, *command, *model;
	manufacture=strtok(deviceid, ";");
//	printf("MFG=%s\n", manufacture+4);
	command=strtok(NULL, ";");
//	printf("CMD=%s\n", command+4);
	model=strtok(NULL, ";");
//	printf("MDL=%s\n", model+4);

	strcpy (printer->manufacture, manufacture+4);
	strcpy (printer->modelname, model+4);

	if(strstr(command, "ESCP") !=NULL){
		printer->language = ECB_LANG_ESCPR;
	}else if(strstr(command, "ESCPAGE") !=NULL){
		printer->language = ECB_LANG_ESCPAGE;
	}

	return rsize;

}

