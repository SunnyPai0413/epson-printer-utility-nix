/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */
#ifndef __EKPCOM_H__
#define __EKPCOM_H__

enum _ERROR_PACKET_NUMBERS
{
  NOERR = 0,
  UNKNOWN_PACKET,
  PRINTER_DOWN,
  SYSTEM_HUNG = 16
};

int sock_open (void);
void sock_close (void);
int sock_write (char*, int*);
int sock_read (char*, int*);
int sock_reopen (void);
int sock_write_abandon_reply (char*, int*);
int sock_write_with_reply (char* buf, int* lp_wsize, char* rbuf, int* lp_rsize);

#endif /* __EKPCOM_H__ */
