/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */
#ifndef __BACKEND_API_H__
#define __BACKEND_API_H__

#define DAEMON_PORT 35587

/*------------------------------- Define Basic Data Types ------------------------------*/
/*******************************************|********************************************/
typedef unsigned char  ECB_UINT8;       /* unsigned  8-bit  Min: 0          Max: 255        */
typedef unsigned short ECB_UINT16;      /* unsigned 16-bit  Min: 0          Max: 65535      */
typedef unsigned int   ECB_UINT32;      /* unsigned 32-bit  Min: 0          Max: 4294967295 */
typedef char           ECB_INT8;        /*   signed  8-bit  Min: -128       Max: 127        */
typedef short          ECB_INT16;       /*   signed 16-bit  Min: -32768     Max: 32767      */
typedef int            ECB_INT32;       /*   signed 32-bit  Min:-2147483648 Max: 2147483647 */
typedef float          ECB_FLOAT;       /*    float 32-bit  Min:3.4E-38     Max: 3.4E+38    */
typedef ECB_INT32      ECB_BOOL;        /* Boolean type                                     */
typedef ECB_INT32      ECB_ERR_CODE;    /* Error code for API's and routines                */
typedef int            ECB_SOCKET;      /* socket discripter                                */


typedef enum
{
  /* from lib-l2/epson-escpr-err.h: enum EPS_PRINTER_STATUS */
  ECB_PRNST_IDLE = 0                             ,    /* Idle (Enable Start Job)      */
  ECB_PRNST_BUSY                                 ,    /* Busy (Disable Start Job)     */
  ECB_PRNST_PRINTING                             ,    /* Printing                     */
  ECB_PRNST_CANCELLING                           ,    /* Cancellation processing      */
  ECB_PRNST_ERROR                                ,    /* Printer has an error         */

  ECB_DAEMON_NO_ERROR = 0,
  ECB_DAEMON_DOWN = 100,         /* add sk -Mon Mar 12 2001 */
  ECB_DAEMON_NO_REPLY,
  ECB_DAEMON_PRINTER_RESET,
  ECB_DAEMON_DEFAULT

}ECB_PRINTER_STS;

typedef enum
{
  /* from lib-l2/epson-escpr-err.h: enum EPS_PRINTER_ERROR */
  ECB_PRNERR_NOERROR = 0                         ,
  ECB_PRNERR_GENERAL                             ,
  ECB_PRNERR_FATAL                               ,
  ECB_PRNERR_INTERFACE                           ,
  ECB_PRNERR_COVEROPEN                           ,
/*  ECB_PRNERR_LEVERPOSITION                       ,*/  /* Not supported by 2006 Model  */
  ECB_PRNERR_PAPERJAM                            ,
  ECB_PRNERR_INKOUT                              ,
  ECB_PRNERR_PAPEROUT                            ,
/*  ECB_PRNERR_INITIALIZESETTING                   ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_UNKNOWN                             ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_PAPERCHANGE_UNCOMP                  ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_PAPERSIZE                           ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_RIBBONJAM                           ,*/  /* Not supported by 2006 Model  */
  ECB_PRNERR_SIZE_TYPE_PATH                      ,
/*  ECB_PRNERR_PAPERTHICKLEVER                     ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_PAPERFEED                           ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_SIMMCOPY                            ,*/  /* Not supported by 2006 Model  */
  ECB_PRNERR_SERVICEREQ                          ,    /* EPS_PRNERR_INKOVERFLOW1      */
/*  ECB_PRNERR_WAITTEAROFFRETURN                   ,*/  /* Not supported by 2006 Model  */
  ECB_PRNERR_MBOX_FULL                             ,    
  ECB_PRNERR_DOUBLEFEED                          ,
/*  ECB_PRNERR_HEADHOT                             ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_PAPERCUTMIS                         ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_HOLDLEVERRELEASE                    ,*/  /* Not supported by 2006 Model  */
  ECB_PRNERR_NOT_CLEANING                        ,
  ECB_PRNERR_PAPERCONFIG                         ,
  ECB_PRNERR_PAPERSLANT                          ,
/*  ECB_PRNERR_CLEANINGNUMOVER                     ,*/  /* Not supported by 2006 Model  */
  ECB_PRNERR_INKCOVEROPEN                        ,
/*  ECB_PRNERR_LFP_INKCARTRIDGE                    ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_CUTTER                              ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_CUTTERJAM                           ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_INKCOLOR                            ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_CUTTERCOVEROPEN                     ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_LFP_INKLEVERRELEASE                 ,*/  /* Not supported by 2006 Model  */
  ECB_PRNERR_LFP_NOMAINTENANCETANK1              ,
/*  ECB_PRNERR_CARTRIDGECOMBINATION                ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_LFP_COMMAND                         ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_LEARCOVEROPEN                       ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_MULTICENSORGAIN                     ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_NOT_AUTOADJUST                      ,*/  /* Not supported by 2006 Model  */
  ECB_PRNERR_FAILCLEANING                        ,
  ECB_PRNERR_NOTRAY                              ,
  ECB_PRNERR_CARDLOADING                         ,
  ECB_PRNERR_CARTRIDGEOVERFLOW                   ,
/*  ECB_PRNERR_LFP_NOMAINTENANCETANK2              ,*/  /* Not supported by 2006 Model  */
/*  ECB_PRNERR_INKOVERFLOW2                        ,*/  /* Not supported by 2006 Model  */
  ECB_PRNERR_BATTERYVOLTAGE                      ,
  ECB_PRNERR_BATTERYTEMPERATURE                  ,
  ECB_PRNERR_BATTERYEMPTY                        ,
  ECB_PRNERR_SHUTOFF                             ,
  ECB_PRNERR_NOT_INITIALFILL                     ,
  ECB_PRNERR_PRINTPACKEND                        ,
/*  ECB_PRNERR_ABNORMALHEAT                        ,*/  /* Not supported by 2006 Model  */
  ECB_PRNERR_SCANNEROPEN                         ,
  ECB_PRNERR_MAINTE_REQUIRED                        ,
  ECB_PRNERR_CDRGUIDEOPEN                        ,
  /* append for 2008 Model  */
  ECB_PRNERR_CDDVDCONFIG                         ,
  ECB_PRNERR_CDREXIST_MAINTE                     ,
  
  ECB_PRNERR_DRIVER_MISMATCH                     ,
  ECB_PRNERR_MEDIA_ERROR                         ,
  ECB_PRNERR_NOZZELECHECK_RECOMMEND              ,
  ECB_PRNERR_WAITING_PAPER_SET                   ,
  
/* Subscrption Error */
  ECB_PRNERR_READYPRINT_SERVICE                  ,  

  ECB_PRNERR_PAPER_LOAD_INCORRECT                ,
  ECB_PRNERR_CANNOT_NOZZELE_CLOGGING             ,

  /* Status Error                                                                     */
  ECB_PRNERR_BUSY    = 200                        ,
  ECB_PRNERR_FACTORY                              ,
  ECB_PRNERR_SHUTDOWN                             ,


  /* Communication Error                                                              */
  ECB_PRNERR_COMM                                 ,
  /* Ink Error                                                                        */

  ECB_PRNERR_CEMPTY                               ,
  ECB_PRNERR_CFAIL                                ,

  /* Printer Condition                                                                */
  ECB_PRNERR_TRAYCLOSE                            ,
  ECB_PRNERR_CDGUIDECLOSE                         ,   /* CDR guide close              */
/*    ECB_PRNERR_OVERHEAT                                  OVERHEAT is not an error     */
  ECB_PRNERR_JPG_LIMIT                            ,   /* Jpeg print data size limit   */
  ECB_PRNERR_DISABEL_CLEANING                     ,   /* can not start Head Cleaning  */

	/* Warnig */
  ECB_PRNWARN_PAPERLOW                        = 300,  /* Paper Low Warning */
  ECB_PRNWARN_MBOX_NEAREND                        ,   /* Maintenance Box Near End Warning */
  ECB_PRNWARN_MAINT_REQUIRED                      ,   /* Maintenance Required Warning     */
  ECB_PRNWARN_CHECK_NOZZLE                        ,   /* Cannot check nozzle Warning     */
  ECB_PRNWARN_CUTTRASH_FULL                       ,   /* Cut trash full Warning     */


}ECB_PRINTER_ERR;


typedef enum
{
  ECB_INK_RESET_OK = 0,
  ECB_INK_RESET_NA,
  ECB_INK_RESET_BUSY,
  ECB_INK_RESET_COMM_ERROR
}ECB_INK_RESET_STS;

#define ECB_INK_NUM		20
#define INKLOW           4
typedef struct _tagECB_PAPER_COUNT_ {
	ECB_INT32	color;
	ECB_INT32	monochrome;
	ECB_INT32	blank;
	ECB_INT32	adf;
	ECB_INT32	color_borderless;
	ECB_INT32	monochrome_borderless;
} ECB_PAPER_COUNT;

typedef struct _tagECB_STATUS_ {
	ECB_INT32		printerStatus;
	ECB_INT32		errorCode;
	ECB_INT32		ink_num;
	ECB_INT32		colors[ECB_INK_NUM];
	ECB_INT32		inklevel[ECB_INK_NUM];
	ECB_INT32		inkstatus[ECB_INK_NUM];
	ECB_PAPER_COUNT paper_count;
	ECB_BOOL		showInkInfo;
	ECB_BOOL		showInkLow;
} ECB_STATUS;


    /*** Ink Cartridge Status                                                           */
    /*** -------------------------------------------------------------------------------*/
#define ECB_INK_ST_NORMAL                        (0)
#define ECB_INK_ST_LOW                           (1)
#define ECB_INK_ST_END                           (2)
#define ECB_INK_ST_NOTPRESENT                    -1
#define ECB_INK_ST_FAIL                          -2
#define ECB_INK_ST_NOTAVAIL                      -3
#define ECB_INK_ST_NOREAD                        -4


#define ECB_NAME_BUFFSIZE  64

#define ECB_LANG_ESCPR     1;
#define ECB_LANG_ESCPAGE   2;

typedef struct _tagECB_PRINTER_ {
	ECB_INT8	manufacture[ECB_NAME_BUFFSIZE];
	ECB_INT8	modelname[ECB_NAME_BUFFSIZE];
	ECB_INT32	language;
} ECB_PRINTER;

int Init_Lib(void);
void Close_Lib(void);
void Cancel_Job(void);
void Resume_Job(void);
ECB_PRINTER_ERR Nozzle_Check(void);
ECB_PRINTER_ERR Head_Cleaning(void);
ECB_PRINTER_STS Get_Status (ECB_STATUS* status);
ECB_INK_RESET_STS Reset_Ink_Counter(int ink);
int Get_Printer_Info(ECB_PRINTER* printer);

#endif /* __EKPCOM_H__ */
