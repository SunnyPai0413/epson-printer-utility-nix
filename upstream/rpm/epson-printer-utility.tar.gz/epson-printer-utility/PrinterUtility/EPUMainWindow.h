/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#ifndef EPUMAINWINDOW_H
#define EPUMAINWINDOW_H

#include "../EPUCommon/EPUCommonDef.h"
#include "EPUView.h"
#include "EPUMaintenanceGuideView.h"

class EPUMainWindow: public QWidget
{
    Q_OBJECT
public:
    EPUMainWindow(QWidget* parent = 0);
    void ButtonDisable();
    void HeadCleanButtonDisable();
    void NozzleCheckButtonAble();
    void ButtonEnable();
    virtual ~EPUMainWindow();

public:
    void ChangeCurrentViewToView(EPUView* epuView);
    void UpdateCurrentPrinterForCurrentView();
    EPUMaintenanceGuideView* getMaintenanceGuideView(){return m_pMaintenanceGuideView;}

private:
    QVBoxLayout*        m_pMainLayout;
    QHBoxLayout*        m_pToolbarLayout;
    QPushButton*        m_pBuyEponInkButton;
    QPushButton*        m_pDriverSettingButton;
    QPushButton*        m_pTestButton;
    QVBoxLayout*        m_pBodyLayout;
    EPUView*            m_pCurrentView;
    EPUMaintenanceGuideView*    m_pMaintenanceGuideView;

private:
    void setupGUI();
    void setupConnection();

protected:
    bool event(QEvent *event);

protected slots:
    void btnBuyInkClicked();
    void btnDriverSettingClicked();
};

#endif // EPUMAINWINDOW_H
