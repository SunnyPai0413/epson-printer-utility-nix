/****************************************************************************
** Meta object code from reading C++ file 'EPUMainView.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "EPUMainView.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'EPUMainView.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_EPUMainView_t {
    QByteArrayData data[8];
    char stringdata0[92];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_EPUMainView_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_EPUMainView_t qt_meta_stringdata_EPUMainView = {
    {
QT_MOC_LITERAL(0, 0, 11), // "EPUMainView"
QT_MOC_LITERAL(1, 12, 25), // "btnShowPrinterListClicked"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 16), // "setPrinterStatus"
QT_MOC_LITERAL(4, 56, 6), // "status"
QT_MOC_LITERAL(5, 63, 15), // "setPrinterState"
QT_MOC_LITERAL(6, 79, 5), // "state"
QT_MOC_LITERAL(7, 85, 6) // "update"

    },
    "EPUMainView\0btnShowPrinterListClicked\0"
    "\0setPrinterStatus\0status\0setPrinterState\0"
    "state\0update"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_EPUMainView[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   34,    2, 0x0a /* Public */,
       3,    1,   35,    2, 0x0a /* Public */,
       5,    1,   38,    2, 0x0a /* Public */,
       7,    0,   41,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void,

       0        // eod
};

void EPUMainView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        EPUMainView *_t = static_cast<EPUMainView *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->btnShowPrinterListClicked(); break;
        case 1: _t->setPrinterStatus((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->setPrinterState((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->update(); break;
        default: ;
        }
    }
}

const QMetaObject EPUMainView::staticMetaObject = {
    { &EPUView::staticMetaObject, qt_meta_stringdata_EPUMainView.data,
      qt_meta_data_EPUMainView,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *EPUMainView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *EPUMainView::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_EPUMainView.stringdata0))
        return static_cast<void*>(const_cast< EPUMainView*>(this));
    return EPUView::qt_metacast(_clname);
}

int EPUMainView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = EPUView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
