/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#ifndef EPUOPERATIONVIEW_H
#define EPUOPERATIONVIEW_H

#include "EPUView.h"

class EPUOperationView : public EPUView
{
    Q_OBJECT
public:
    explicit EPUOperationView(QWidget *parent = 0);
    
signals:
    
public slots:

protected:
    QVBoxLayout*            m_pGuideLayout;
    QHBoxLayout*            m_pGuideTitleLayout;
    QLabel*                 m_pGuideIconView;
    QLabel*                 m_pGuideLabel;
};

#endif // EPUOPERATIONVIEW_H
