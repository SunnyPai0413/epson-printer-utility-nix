/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#include <QtWidgets/QApplication>
#include "EPUGlobal.h"
#include <sys/stat.h>
#include <QTranslator>
#include <QLocale>

QString g_modelName = NULL;
QString g_printerID = NULL;
QString g_inifileName = NULL;

int main(int argc, char** argv)
{

    QApplication app(argc, argv);

    app.setApplicationName("EpsonPrinterUtility");

    QTranslator translator;


    QString locale;
    locale = setlocale(LC_CTYPE, NULL);

    QString current_langfile = "/opt/epson-printer-utility/resource/Languages/";

//    QString current_langfile = "Languages/";   //    For Debug


    current_langfile += "utilitytr_";
//    current_langfile += QLocale::system().name();
    current_langfile += locale;

//	printf("%s \n", qPrintable(current_langfile));


    translator.load(current_langfile);
    app.installTranslator(&translator);

//-------Read Previous Printer ------------------

//Make Save Directory
	char ini_dir[256], ini_file[256];
    //Get home folder
 	char *user = (char*)getenv("SUDO_USER"); 
    if(user == NULL){
        user = (char*)getenv("USER"); 
    }

	sprintf(ini_dir,"/home/%s/%s", user, ".EpsonPrinterUtility");
	sprintf(ini_file,"%s/%s", ini_dir, "utility.ini");

    struct stat statBuf;

    if (stat(ini_dir, &statBuf) != 0){ // directory not exist
		system("mkdir ~/.EpsonPrinterUtility");
		system("chown ${SUDO_USER:-$USER}:${SUDO_USER:-$USER} /home/${SUDO_USER:-$USER}/.EpsonPrinterUtility");
	}	

//Read ini File
	char modelName[256] , printerID[256];
	memset(&modelName, 0, sizeof(modelName));
	memset(&printerID, 0, sizeof(printerID));

	char buf1[256], buf2[256];
	char *p;
	FILE *fp;
	if( (fp = fopen(ini_file, "r")) != NULL){
		if(fgets( buf1, 256, fp )!= NULL){
			 p = strchr(buf1, '\n');
			 if (p) {
				*p = '\0';
			 }
			 strcpy(modelName , buf1);
		}
		if(fgets( buf2, 256, fp )!= NULL){
			 p = strchr(buf2, '\n');
			 if (p) {
				*p = '\0';
			 }

			 strcpy(printerID , buf2);	
		}		
		fclose(fp);
	}

	g_modelName = modelName;
	g_printerID = printerID;
	g_inifileName = ini_file;

//-----------------------------------------------------

    EPUMainController mainController;
    SetMainController(&mainController);
    mainController.ShowMainWindow();

    return app.exec();

}


