/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#include "EPUGlobal.h"

EPUMainController* g_pMainController = NULL;

void SetMainController(EPUMainController *mainController)
{
    g_pMainController = mainController;
}

EPUMainController* GetMainController()
{
    return g_pMainController;
}

