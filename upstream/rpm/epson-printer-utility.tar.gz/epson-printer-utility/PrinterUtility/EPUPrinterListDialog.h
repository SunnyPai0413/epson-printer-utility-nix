/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#ifndef EPUPRINTERLISTDIALOG_H
#define EPUPRINTERLISTDIALOG_H

#include <QtWidgets>
#include <QDialog>
#include <unistd.h>
#include "../EPUCommon/EPUCommonDef.h"
#include "EPUPrinter.h"
#include "../EPUCommon/EThread.h"

class EPUPrinterListDialog : public QDialog
{
    Q_OBJECT
public:
    explicit EPUPrinterListDialog(QWidget *parent = 0);
    virtual ~EPUPrinterListDialog();

public:
    int DoModal();
    void StartUpdatePrinterList();
    static EThreadReturnValue RunRefreshPrinterList(void* object, EThreadParam param);
    void runRefreshPrinterListLoop();

private:
    void addPrinter(EPUPrinter* printer);

public:
    void updatePrinterList();
    
signals:
    
protected slots:
    void btnUpdateClicked();
    void btnOKClicked();

protected:
    bool event(QEvent *event);
    void closeEvent(QCloseEvent *event);

private:
    EThread*            m_pRefreshPrinterListThread;
    QVBoxLayout*        m_pMainLayout;
    QListView*          m_pListView;
    QStandardItemModel* m_pSourceModel;
    QItemSelectionModel* m_pSelectionModel;

    QHBoxLayout*        m_pButtonLayout;
    QPushButton*        m_pUpdateButton;
    QPushButton*        m_pOKButton;

    bool                m_bKeepRefreshThreadUpdatePrListRunning;
    bool                m_bRefreshThreadUpdatePrListStopped;
};

#endif // EPUPRINTERLISTDIALOG_H
