/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#ifndef EPUINKLEVELVIEW_H
#define EPUINKLEVELVIEW_H

#include <QWidget>
#include <QPainter>

class EPUInkLevelView : public QWidget
{
 //   Q_OBJECT
public:
    explicit EPUInkLevelView(QColor color, const QString& inkName = QString::null, QWidget *parent = 0);

public:
    void SetInkColor(QColor color);
    void SetInkLevel(int inkLevel);
    void SetSmartCharge(bool smartcharge);
    void SetInkEndCartridge(int num, QString* name);
    void SetInkName(const QString& inkName);
    void SetInkInfo(QColor color, const QString& inkName, int inkLevel);
    
signals:
    
public slots:

protected:
    void paintEvent(QPaintEvent *event);

private:
    QColor              m_inkColor;
    QString             m_strInkName;
    int                 m_nInkLevel;
    bool                m_nSmartCharge;
    QString             m_strInkEndList[20];
	int					m_InkEndNum;
};

#endif // EPUINKLEVELVIEW_H
