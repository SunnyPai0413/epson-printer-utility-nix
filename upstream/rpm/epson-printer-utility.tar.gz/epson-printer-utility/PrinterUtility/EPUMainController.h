/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#ifndef EPUMAINCONTROLLER_H
#define EPUMAINCONTROLLER_H

#include "EPUMainWindow.h"
#include "EPUCallbackObject.h"
#include "EPUMainView.h"
#include "EPUMaintenanceGuideView.h"
#include "EPSPrinterController.h"
#include <QTimer>
#include <unistd.h>

class EPUMainController: public EPUCallbackObject
{
public:
    EPUMainController();
    virtual ~EPUMainController();

public:
    void ShowMainWindow();
    //EPUMainWindow* GetMainWindow() {return m_pMainWindow;}

    //callback
    void EPUViewDidCloseWithCode(QWidget *epuView, EPUCallbackCode code);
    void EPUViewDisAble();
    void EPUViewDisAbleHeadClean();
    void EPUViewAbleNozzleCheck();
    void EPUViewEnAble();

    ///notify
    void PostNotify(EPUEventType eventType);

    //update
    void UpdateCurrentPrinterStatus();
    void StartMainViewTimer(){m_pMainView->StartTimer();}
    void StopMainViewTimer(){m_pMainView->StopTimer();}
private:
    EPUMainWindow*              m_pMainWindow;
    EPUMainView*                m_pMainView;
    EPUPrinter*                 m_pCurrenPrinter;
};

#endif // EPUMAINCONTROLLER_H
