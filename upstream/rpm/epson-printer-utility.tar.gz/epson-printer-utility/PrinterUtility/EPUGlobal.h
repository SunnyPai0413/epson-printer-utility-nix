/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#ifndef EPUGLOBAL_H
#define EPUGLOBAL_H

#include "EPUMainController.h"

extern void SetMainController(EPUMainController* mainController);
extern EPUMainController* GetMainController();

#endif // EPUGLOBAL_H
