/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#ifndef EPSCOMMONLIBDEFINE_H
#define EPSCOMMONLIBDEFINE_H

#include <QVector>

#define MAX_PRINTER_MODEL_NAME_LEN 64

typedef struct _EPSPrinter
{
    qint8 modelName[MAX_PRINTER_MODEL_NAME_LEN];
    qint8 printerId;
    _EPSPrinter()
    {
        memset(modelName, 0x00, sizeof(modelName));
        printerId = -1;
    }
} EPSPrinter;

#endif // EPSCOMMONLIBDEFINE_H
