/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */
#ifndef ERR_H
#define ERR_H

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdarg.h>

#define DEBUG_PATH "/tmp/epSTM.txt"
#define EPS_DEBUG_PATH2 "/tmp/esp_time.txt"

enum msgtype {
	MSGTYPE_ERROR = 0,
	MSGTYPE_WARNING,
	MSGTYPE_INFO,
	MSGTYPE_MESSAGE
};



void err_init (const char *);
void err_msg (enum msgtype, const char *, ...);
void err_fatal (const char *, ...);
void err_system (const char *, ...);

void debug_msg(const char *, ...);
void debugt_msg(char *  fmt, ...);



#endif /* ERR_H */
