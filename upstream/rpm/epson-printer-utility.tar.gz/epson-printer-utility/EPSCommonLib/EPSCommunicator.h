/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#ifndef EPSCOMMUNICATOR_H
#define EPSCOMMUNICATOR_H

#include "./escpr-lib/inc/epson-escpr-media.h"
#include "./escpr-lib/inc/epson-cbt.h"
#include "./escpr-lib/inc/epson-protocol.h"
#include "./escpr-lib/inc/epson-net-snmp.h"
#include "./escpr-lib/inc/epson-net-lpr.h"
#include "./escpr-lib/inc/epson-net-lpr.h"
#include "./escpr-lib/inc/epson-usb.h"
//#include "linux_cmn.h"
//#include "linux_net.h"
#include "./escpr-lib/inc/epson-protocol.h"
//#include "epsmp-common-functions.h"
#include "./epsmp/linux/epsmp-linux-portal-io.h"
#include "./epsmp/epsmp-file-io.h"
#include "./escpr-lib/inc/epson-escpr-api.h"
#include "./escpr-lib/inc/epson-escpr-def.h"

#include "../EPUCommon/EThread.h"
#include "EPSCommonLibDefine.h"

class EPSPrinterController;

class EPSCommunicator
{
private:
    EPSCommunicator();
    virtual ~EPSCommunicator();

public:
    static EPSCommunicator* GetInstance();
    static void ReleaseInstance();

public:
    bool InitializeCommunicator();
    void StartFindPrinter();

    void SetPrinterController(EPSPrinterController* pController) {m_pPrinterController = pController;}

    //QVector<EPSPrinter> GetPrinterList();
    QVector<EPS_PRINTER> GetPrinterList(){return m_printerList;}

    static EPS_INT32 FindPrinterCallback(EPS_PRINTER printer);
    static EThreadReturnValue RunFindPrinterThread(void* object, EThreadParam param);
    EPS_INT32 didFindPrinter(EPS_PRINTER printer);
    void internalRunFindPrinterLoop();

    bool ConnectToPrinter(const QString& printerName, const QString &printerId);
    bool GetCurrentPrinterStatus(EPS_STATUS* status, EPS_INK_INFO* inkInfo);

    EPS_ERR_CODE NozzleCheckPrinter();
    EPS_ERR_CODE HeadCleanPrinter();
    EPS_INT32 getSizeOfPrinterList(){return m_printerList.size();}
    bool GetPrinterStatus(EPS_STATUS* status);

private:
    static EPSCommunicator* pSelf;
    EThread*                m_pFindPrinterThread;
    bool                    m_bKeepFindPrinterThread;
    EPSPrinterController*   m_pPrinterController;

    QVector<EPS_PRINTER>  m_printerList;
    EPS_PRINTER           m_currentPrinter;
    APP_SEARCH_ATTRIBS    m_searchAttr;
};

#endif // EPSCOMMUNICATOR_H
