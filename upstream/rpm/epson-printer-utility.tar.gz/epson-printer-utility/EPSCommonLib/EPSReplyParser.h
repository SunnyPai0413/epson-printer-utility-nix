/*
 *   Copyright (c) 2021  Seiko Epson Corporation                 All rights reserved.
 *
 *   Copyright protection claimed includes all forms and matters of
 *   copyrightable material and information now allowed by statutory or judicial
 *   law or hereinafter granted, including without limitation, material generated
 *   from the software programs which are displayed on the screen such as icons,
 *   screen display looks, etc.
 *
 */

#ifndef EPSREPLYPARSER_H
#define EPSREPLYPARSER_H

#include "epson-escpr-media.h"
#include "epson-cbt.h"
#include "epson-protocol.h"
#include "epson-net-snmp.h"
#include "epson-net-lpr.h"
#include "epson-net-lpr.h"
#include "epson-usb.h"
#include "linux_cmn.h"
#include "linux_net.h"

class EPSReplyParser
{
private:
    EPSReplyParser();
    virtual ~EPSReplyParser();

public:
    static EPSReplyParser* GetInstance();
    static void ReleaseInstance();

public:
    bool InitializeParser();

    //bool ParseStatus(EPRP_STATUS* status, const EPS_UINT8* buffer, EPS_INT32 bufferSize);
    //bool ParseInkInfo(EPRP_INK_INFO* inkInfo, const EPS_UINT8* buffer, EPS_INT32 bufferSize);

private:
    static EPSReplyParser* pSelf;
};

#endif // EPSREPLYPARSER_H
